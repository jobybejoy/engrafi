<!DOCTYPE html>
<html>
<head>
	<title>User list - PDF</title>
	
</head>
<body style="font-family:sans-serif">
    <div style="background-color:white;">
        <div style="background-color:#fafafa;border: 1px solid #ddd;">
            <div style="min-width:90%;color:#fff;background-color:#384148;padding:20px 0">
                <span style="display:inline-block;width:5%;margin:0;padding-left:20px">#</span>
                <span style="display:inline-block;width:15%;margin:0;padding-left:20px">Register Number</span>
                <span style="display:inline-block;width:30%;margin:0;padding-left:20px">Name</span>
                <span style="display:inline-block;width:35%;margin:0;padding-left:20px">Email</span>
            </div>
            <div>
                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div style="margin:0;padding-bottom:10px;padding-top:15px;border-bottom: 2px solid #ddd">
                    <span style="display:inline-block;width:5%;margin:0;padding-left:20px;"><?php echo e($key + 1); ?></span>
                    <span style="display:inline-block;width:15%;margin:0;padding-left:20px;"><?php echo e($value->student_id); ?></span>
                    <span style="display:inline-block;width:30%;margin:0;padding-left:20px;"><?php echo e($value->name); ?></span>
                    <span style="display:inline-block;width:35%;margin:0;padding-left:20px;"><?php echo e($value->email); ?></span>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</body>
</html>